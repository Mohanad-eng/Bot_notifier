import discord
import asyncio
import requests
from bs4 import BeautifulSoup
import json
import os
import logging

# --enter here token please 
TOKEN = "put Token here" 

# here enter the channels in discord server
CATEGORY_CHANNELS = {
    "general": "channel_id",
    "chat": "channel_id"
}


CHECK_INTERVAL = 60 # here checks every 60 s
SENT_TOPICS_FILE = "sent_topics.json" # sent the topics to the json file

# use headers as it might block the bot
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive"
}

# ----------logging-----------
logging.basicConfig(
    filename="log.txt",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# load sent topics from json 
def load_sent_topics():
    if os.path.exists(SENT_TOPICS_FILE):
        with open(SENT_TOPICS_FILE, "r", encoding="utf-8") as f:
            return set(json.load(f))
    return set()

# save sent topics in json after each post is sent
def save_sent_topics(topics_set):
    with open(SENT_TOPICS_FILE, "w", encoding="utf-8") as f:
        json.dump(list(topics_set), f, indent=2)

# initialize the bot 
intents = discord.Intents.default()
intents.message_content = True
bot = discord.Client(intents=intents)

# load orevious sent topic
sent_topics = load_sent_topics()

@bot.event
async def on_ready():
    logging.info(f"✅ Logged in as {bot.user}")
    print(f"✅ Logged in as {bot.user}")
    asyncio.create_task(check_forum())


async def check_forum():
    await bot.wait_until_ready()
    print(" Started checking the forum...")
    logging.info(" Started checking the forum...")
    url = "https://erc2025.husarion.com/"

    while not bot.is_closed():
        try:
            response = requests.get(url, headers=HEADERS, timeout=15)
            response.raise_for_status()

            soup = BeautifulSoup(response.text, "html.parser")
            topics = soup.select("a.raw-topic-link")  

            for topic in topics:
                title = topic.get_text(strip=True)
                href = topic.get("href")

                if not href or not title:
                    continue  

                full_link = f"https://erc2025.husarion.com{href}"

                if title not in sent_topics:
                    if "announcement" in title.lower():
                        channel_id = CATEGORY_CHANNELS["general"]
                    else:
                        channel_id = CATEGORY_CHANNELS["chat"]

                    channel = bot.get_channel(channel_id)
                    if channel:
                        await channel.send(f" New Topic: **{title}**\n {full_link}")
                        sent_topics.add(title)
                        save_sent_topics(sent_topics)
                        logging.info(f" Sent topic: {title}")
                    else:
                        logging.warning(f" Could not find channel with ID {channel_id}")

        except Exception as e:
            logging.error(f" Error during scraping or sending: {e}")
            print(f" Error during scraping or sending: {e}")

        await asyncio.sleep(CHECK_INTERVAL)
# start bot
bot.run(TOKEN)
