import requests

try:
    response = requests.get("https://erc2025.husarion.com/", timeout=20)
    print("✅ Page loaded! Length:", len(response.text))
except requests.exceptions.RequestException as e:
    print("❌ Error:", e)
